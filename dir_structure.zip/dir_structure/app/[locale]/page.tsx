import TATCGWebsite from "../TATCGWebsite";

export default function Page() {
  return <TATCGWebsite />;
}
